package com.orangehrm.utils;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;
import java.util.List;

public class DropdownSelector {
	private WebDriver driver;
	private WebDriverWait wait;

	public DropdownSelector(WebDriver driver) {
		this.driver = driver;
		this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	}
	
	//not used
	public void selectOption(String dropdownLocatorXpath, String optionXpath) {
		// Locate the dropdown element and click it to display options
		WebElement dropdown = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(dropdownLocatorXpath)));
		dropdown.click();

		// Wait for the option to be visible and click it
		WebElement option = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(optionXpath)));
		option.click();

	}

	public void selectOptionUserRole(String dropdownLocator, String option, String role) {

		WebElement dropdownTrigger = driver.findElement(By.xpath(dropdownLocator));
		dropdownTrigger.click();

		List<WebElement> list1 = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath(option)));

		//System.out.println("list1.size() " + list1.size());

		for (WebElement webElement : list1) {
		//	System.out.println("webElement.getText() " + webElement.getText());

			if (webElement.getText().equals(role)) {
				//System.out.println("webElement.getText() " + webElement.getText());

				//System.out.println("yes");
				webElement.click();
				break;
			}
		}

	}

	public void selectOptionFromList(String dropdownLocator, String option, String status) {

		WebElement dropdownTrigger = driver.findElement(By.xpath(dropdownLocator));
		dropdownTrigger.click();

		List<WebElement> list1 = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath(option)));

		//System.out.println("list1.size() " + list1.size());

		for (WebElement webElement : list1) {
			//System.out.println("webElement.getText() " + webElement.getText());

			if (webElement.getText().equals(status)) {
				//System.out.println("webElement.getText() " + webElement.getText());

				webElement.click();
				break;
			}
		}

	}

}

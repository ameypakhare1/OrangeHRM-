package com.orangehrm.utils;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AutoCompleteDropdownSelector {
	private WebDriver driver;
	private WebDriverWait wait;

	public AutoCompleteDropdownSelector(WebDriver driver) {
		this.driver = driver;
		this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	}

	// used in admin module for employee addition to admin list
	public void selectOptionForEmployeeName(String dropdownLocatorXpath, String optionXpath, String employee_name) {

		driver.findElement(By.xpath(dropdownLocatorXpath)).sendKeys(employee_name);

		// Step 2: Wait for the autocomplete suggestions to appear
		WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(15));

		List<WebElement> suggestions = wait1
				.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath(optionXpath)));

		System.out.println("suggestions.size() " + suggestions.size());

		// Step 3: Iterate through the suggestions to find the desired one
		for (WebElement suggestion : suggestions) {
			System.out.println("suggestion " + suggestion.getText());
			if (suggestion.getText().equals(employee_name)) {
				// Step 4: Click on the desired suggestion
				suggestion.click();
				break;
			}
		}
	}
}

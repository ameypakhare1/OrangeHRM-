package com.orangehrm.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage {
	WebDriver driver;

	// Constructor
	public LoginPage(WebDriver driver) {
		this.driver = driver;
	}

	By username_locator = By.xpath("//*[@id=\"app\"]/div[1]/div/div[1]/div/div[2]/div[2]/form/div[1]/div/div[2]/input");
	By password_locator = By.xpath("//*[@id=\"app\"]/div[1]/div/div[1]/div/div[2]/div[2]/form/div[2]/div/div[2]/input");
	By login_button_locator = By.xpath("//button[@type='submit']");

	public void enterUserName(String text) {
		driver.findElement(username_locator).sendKeys(text);
	}

	public void enterPassword(String text) {
		driver.findElement(password_locator).sendKeys(text);
	}

	public void clickLoginButton() {
		driver.findElement(login_button_locator).click();
	}

	public void login(String username, String password) {
		enterUserName(username);
		enterPassword(password);
		clickLoginButton();
	}

}

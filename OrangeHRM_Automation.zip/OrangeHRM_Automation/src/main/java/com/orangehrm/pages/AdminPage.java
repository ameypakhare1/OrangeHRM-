package com.orangehrm.pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.orangehrm.utils.AutoCompleteDropdownSelector;
import com.orangehrm.utils.DropdownSelector;

public class AdminPage {
	WebDriver driver;

	// Constructor to initialize the WebDriver
	public AdminPage(WebDriver driver) {
		this.driver = driver;
	}

	// Locators
	By adminTab = By.xpath("//*[@id=\"app\"]/div[1]/div[1]/aside/nav/div[2]/ul/li[1]/a");
	By addUserButton = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div[2]/div[1]/button");
	By userRoleDropdown = By
			.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[1]/div/div[1]/div/div[2]/div/div/div[1]");
	By employeeNameField = By
			.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[1]/div/div[2]/div/div[2]/div/div/input");
	By usernameField = By
			.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[1]/div/div[4]/div/div[2]/input");
	By statusDropdown = By
			.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[1]/div/div[3]/div/div[2]/div/div/div[1]");
	By passwordField = By
			.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[2]/div/div[1]/div/div[2]/input");
	By confirmPasswordField = By
			.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[2]/div/div[2]/div/div[2]/input");
	By saveButton = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[3]/button[2]");
	By searchUsernameField = By
			.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div[1]/div[2]/form/div[1]/div/div[1]/div/div[2]/input");
	By searchButton = By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div[1]/div[2]/form/div[2]/button[2]");
	String dropdownLocatorXpathForEmployeeName = "//input[@placeholder='Type for hints...']";
	String optionXpathForEmployeeName;

	// Methods to interact with elements
	public void navigateToAdminTab() {
		System.out.println("navigateToAdminTab running ...");
		driver.findElement(adminTab).click();
	}

	public void clickAddUser() {
		driver.findElement(addUserButton).click();
	}

	public void selectUserRole(String role) {

		DropdownSelector dropdownSelector = new DropdownSelector(driver);

		// Define the XPath to the dropdown and the option text
		String dropdownXPath = "//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[1]/div/div[1]/div/div[2]/div/div/div[1]";
		String optionXpath = "//div[@class='oxd-form-row']//div[3]";

		// Select the desired option
		dropdownSelector.selectOptionUserRole(dropdownXPath, optionXpath, role);

	}

	public void enterEmployeeName(String employee_name) {
		AutoCompleteDropdownSelector autocomplete_option = new AutoCompleteDropdownSelector(driver);
		optionXpathForEmployeeName = "//div[@role='listbox']//span[text()='" + employee_name + "']";
		autocomplete_option.selectOptionForEmployeeName(dropdownLocatorXpathForEmployeeName, optionXpathForEmployeeName,
				employee_name);

	}

	public void selectStatus(String status) {
		DropdownSelector dropdownSelector = new DropdownSelector(driver);

		// Define the XPath to the dropdown and the option text
		String dropdownXPath = "//div[contains(text(),'-- Select --')]";
		String optionXpath = "//div[@role='listbox' and contains(@class, 'oxd-select-dropdown')]//div";

		// Select the desired option
		dropdownSelector.selectOptionFromList(dropdownXPath, optionXpath, status);
	}

	public void enterUsername(String username) {
		driver.findElement(usernameField).sendKeys(username);
	}

	public void enterPassword(String password) {
		driver.findElement(passwordField).sendKeys(password);
	}

	public void enterConfirmPassword(String confirmPassword) {
		driver.findElement(confirmPasswordField).sendKeys(confirmPassword);
	}

	public void clickSave() {
		driver.findElement(saveButton).click();
	}

	public void searchUsername(String username) {
		driver.findElement(searchUsernameField).sendKeys(username);
		driver.findElement(searchButton).click();
	}
}

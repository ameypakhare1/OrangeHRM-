package com.orangehrm.tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.safari.SafariDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import com.orangehrm.pages.AdminPage;
import com.orangehrm.pages.LoginPage;

import java.net.URL;
import java.time.Duration;
import java.util.concurrent.TimeUnit;

public class TestBase {
	public WebDriver driver;
	public LoginPage loginPage;
	public AdminPage adminPage;

	@BeforeSuite
	public void setUp() {
	    driver = new ChromeDriver();

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

		driver.get("http://127.0.0.1/orangehrm-5.7/orangehrm-5.7/web/index.php/auth/login");
		driver.manage().window().maximize();
		loginPage = new LoginPage(driver);

		// Perform login actions
		loginPage.enterUserName("AmeyOrange");
		loginPage.enterPassword("Amey@2025");
		loginPage.clickLoginButton();
		
		adminPage = new AdminPage(driver);
	    System.out.println("BeforeSuite: Test Suite Setup Started");

	}

	@AfterSuite
	public void tearDown() {
		if (driver != null) {
			driver.quit();
		    System.out.println("AfterSuite: Test Suite Cleanup Completed");

		}
	}
}

package com.orangehrm.tests;

import org.testng.annotations.Test;

import com.orangehrm.pages.LoginPage;

import org.testng.annotations.BeforeMethod;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;

public class LoginTest {
	WebDriver driver;
    LoginPage loginPage;
 
  @BeforeMethod
  public void setUp() {
		WebDriver driver = new ChromeDriver();

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

		driver.get("http://127.0.0.1/orangehrm-5.7/orangehrm-5.7/web/index.php/auth/login");
		driver.manage().window().maximize();
		loginPage = new LoginPage(driver);
  }
  @Test
  public void testValidLogin() {
	  loginPage.enterUserName("AmeyOrange");
	  loginPage.enterPassword("Amey@2025");
	  loginPage.clickLoginButton();
	  
  }

  @AfterMethod
  public void tearDown() {
	  //driver.quit();
  }

}

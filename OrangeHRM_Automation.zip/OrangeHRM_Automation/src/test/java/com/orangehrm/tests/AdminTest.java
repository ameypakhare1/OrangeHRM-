package com.orangehrm.tests;

import com.orangehrm.pages.LoginPage;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

public class AdminTest extends TestBase {

	@Test(priority = 1)
	public void addUserTest() {
		adminPage.navigateToAdminTab();
		adminPage.clickAddUser();
		adminPage.selectUserRole("ESS");
		adminPage.enterEmployeeName("Cristiano R Ronaldo");
		adminPage.selectStatus("Enabled");
		adminPage.enterUsername("cristiano12345");
		adminPage.enterPassword("Amey@2025");
		adminPage.enterConfirmPassword("Amey@2025");
		adminPage.clickSave();

	}

	@Test(priority = 2)
	public void searchUserTest() {

		adminPage.navigateToAdminTab();
		adminPage.clickAddUser();
		adminPage.selectUserRole("ESS");
		adminPage.enterEmployeeName("Cristiano R Ronaldo");
		adminPage.selectStatus("Enabled");
		adminPage.enterUsername("cristiano12345");
		adminPage.enterPassword("Amey@2025");
		adminPage.enterConfirmPassword("Amey@2025");
		adminPage.clickSave();

	}

	@Test(priority = 3)
	public void missingRequiredFields() {

		adminPage.navigateToAdminTab();
		adminPage.clickAddUser();
		adminPage.selectUserRole("ESS");
		adminPage.enterEmployeeName("");
		adminPage.selectStatus("");
		adminPage.enterUsername("");
		adminPage.enterPassword("Amey@2025");
		adminPage.enterConfirmPassword("Amey@2025");
		adminPage.clickSave();

	}
	
	@Test(priority = 4)
	public void editExistingUser() {

		adminPage.navigateToAdminTab();
		adminPage.clickAddUser();
		adminPage.selectUserRole("ESS");
		adminPage.enterEmployeeName("");
		adminPage.selectStatus("");
		adminPage.enterUsername("");
		adminPage.enterPassword("Amey@2025");
		adminPage.enterConfirmPassword("Amey@2025");
		adminPage.clickSave();

	}

}
